UPDATE RESERVA SET
cancelado = 'Y' 
WHERE idCliente = X AND idEspacio = Y;
--LOS VALORES X,Y son los que en el proyecot java son reemplazados por los id respectivos.