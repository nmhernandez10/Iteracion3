DELETE FROM ESPACIOS
WHERE ID = X;
--LOS VALORES X son los que en el proyecto java son reemplazados por los id respectivos.